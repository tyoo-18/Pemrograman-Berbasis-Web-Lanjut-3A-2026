<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Pengguna - Admin</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f4f6f9; }
        .container { background: white; padding: 25px; border-radius: 8px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #007bff; color: white; }
        .alert { padding: 10px; background: #d4edda; color: #155724; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>👥 Kelola Pengguna & Role</h2>
        <a href="<?php echo e(route('admin.dashboard')); ?>">← Kembali ke Dashboard</a>

        <?php if(session('success')): ?>
            <div class="alert"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Role Saat Ini</th>
                    <th>Ubah Role</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($u->name); ?></td>
                    <td><?php echo e($u->email); ?></td>
                    <td><strong><?php echo e($u->roles->pluck('name')->implode(', ')); ?></strong></td>
                    <td>
                        <form action="<?php echo e(route('admin.users.updateRole', $u->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <select name="role" onchange="this.form.submit()">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($r->name); ?>" <?php echo e($u->hasRole($r->name) ? 'selected' : ''); ?>>
                                        <?php echo e(ucfirst($r->name)); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </form>
                    </td>
                    <td>
                        <form action="<?php echo e(route('admin.users.destroy', $u->id)); ?>" method="POST" onsubmit="return confirm('Hapus user ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" style="color:red;">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html><?php /**PATH D:\Pemrograman-Berbasis-Web-Lanjut-3A-2026\Modul-6\perpustakaan_250441100031\resources\views/admin/users.blade.php ENDPATH**/ ?>