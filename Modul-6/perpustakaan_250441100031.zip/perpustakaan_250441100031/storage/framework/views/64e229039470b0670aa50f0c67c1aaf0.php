<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Riwayat Peminjaman Saya</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f4f6f9; }
        .container { background: white; padding: 25px; border-radius: 8px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #28a745; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <h2>📖 Riwayat Peminjaman Saya</h2>
        <a href="<?php echo e(route('siswa.dashboard')); ?>">← Kembali ke Dashboard</a> | 
        <a href="<?php echo e(route('buku.index')); ?>">Lihat Katalog Buku</a>

        <?php if(session('success')): ?>
            <div style="padding:10px; background:#d4edda; color:#155724; margin-top:10px;"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div style="padding:10px; background:#f8d7da; color:#721c24; margin-top:10px;"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>Judul Buku</th>
                    <th>Tanggal Pinjam</th>
                    <th>Tanggal Kembali</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $riwayats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($r->buku->judul ?? '-'); ?></td>
                    <td><?php echo e($r->tanggal_pinjam); ?></td>
                    <td><?php echo e($r->tanggal_kembali ?? '-'); ?></td>
                    <td><strong><?php echo e(strtoupper($r->status)); ?></strong></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" style="text-align:center;">Belum ada riwayat peminjaman buku.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html><?php /**PATH D:\Pemrograman-Berbasis-Web-Lanjut-3A-2026\Modul-6\perpustakaan_250441100031\resources\views/siswa/riwayat.blade.php ENDPATH**/ ?>