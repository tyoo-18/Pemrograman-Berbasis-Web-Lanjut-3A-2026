<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Petugas</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; }
        .btn { display: inline-block; padding: 10px 15px; background: #17a2b8; color: white; text-decoration: none; border-radius: 4px; margin-right: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>📋 Dashboard Petugas</h2>
        <p>Selamat datang, <strong><?php echo e(Auth::user()->name); ?></strong>!</p>

        <div style="margin: 20px 0;">
            <a href="<?php echo e(route('petugas.peminjaman.index')); ?>" class="btn">📋 Kelola Peminjaman & Pengembalian</a>
            <a href="<?php echo e(route('buku.index')); ?>" class="btn" style="background:#28a745;">📚 Kelola Data Buku</a>
        </div>

        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" style="background:#dc3545; color:white; border:none; padding:10px 15px; border-radius:4px; cursor:pointer;">Logout</button>
        </form>
    </div>
</body>
</html><?php /**PATH D:\Pemrograman-Berbasis-Web-Lanjut-3A-2026\Modul-5\perpustakaan_250441100031\resources\views/petugas/dashboard.blade.php ENDPATH**/ ?>