<h2>Detail Peminjaman</h2>

<p>ID: <?php echo e($peminjaman->id); ?></p>
<p>Nama Siswa: <?php echo e($peminjaman->user->name); ?></p>
<p>Judul Buku: <?php echo e($peminjaman->buku->judul ?? '-'); ?></p>
<p>Status: <?php echo e($peminjaman->status); ?></p><?php /**PATH D:\Pemrograman-Berbasis-Web-Lanjut-3A-2026\Modul-6\perpustakaan_250441100031\resources\views/peminjaman/show.blade.php ENDPATH**/ ?>