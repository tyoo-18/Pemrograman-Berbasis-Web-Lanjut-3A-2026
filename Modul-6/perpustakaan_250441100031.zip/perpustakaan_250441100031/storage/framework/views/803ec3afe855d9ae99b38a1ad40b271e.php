<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Peminjaman - Petugas</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f4f6f9; }
        .container { background: white; padding: 25px; border-radius: 8px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #17a2b8; color: white; }
        .btn-setuju { background: #28a745; color: white; padding: 5px 10px; border:none; border-radius:4px; cursor:pointer;}
        .btn-tolak { background: #dc3545; color: white; padding: 5px 10px; border:none; border-radius:4px; cursor:pointer;}
        .btn-kembali { background: #007bff; color: white; padding: 5px 10px; border:none; border-radius:4px; cursor:pointer;}
    </style>
</head>
<body>
    <div class="container">
        <h2>📋 Kelola Peminjaman & Pengembalian Buku</h2>
        <a href="<?php echo e(route('petugas.dashboard')); ?>">← Kembali ke Dashboard</a>

        <?php if(session('success')): ?>
            <div style="padding:10px; background:#d4edda; color:#155724; margin-top:10px;"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>Siswa</th>
                    <th>Judul Buku</th>
                    <th>Tanggal Pinjam</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($p->user->name); ?></td>
                    <td><?php echo e($p->buku->judul ?? 'Buku Dihapus'); ?></td>
                    <td><?php echo e($p->tanggal_pinjam); ?></td>
                    <td><strong><?php echo e(strtoupper($p->status)); ?></strong></td>
                    <td>
                        <?php if($p->status === 'diproses'): ?>
                            <form action="<?php echo e(route('petugas.peminjaman.updateStatus', $p->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <input type="hidden" name="status" value="dipinjam">
                                <button type="submit" class="btn-setuju">Setujui</button>
                            </form>
                            <form action="<?php echo e(route('petugas.peminjaman.updateStatus', $p->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <input type="hidden" name="status" value="ditolak">
                                <button type="submit" class="btn-tolak">Tolak</button>
                            </form>
                        <?php elseif($p->status === 'dipinjam'): ?>
                            <form action="<?php echo e(route('petugas.peminjaman.updateStatus', $p->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <input type="hidden" name="status" value="dikembalikan">
                                <button type="submit" class="btn-kembali">Tandai Dikembalikan</button>
                            </form>
                        <?php else: ?>
                            <span>- Selesai -</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html><?php /**PATH D:\Pemrograman-Berbasis-Web-Lanjut-3A-2026\Modul-5\perpustakaan_250441100031\resources\views/petugas/peminjaman.blade.php ENDPATH**/ ?>